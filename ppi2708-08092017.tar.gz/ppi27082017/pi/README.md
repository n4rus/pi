# Pi
Any content must be quantifiable. 
For this Pi must go on.
n4rus is an statement of Pi.

q = n4rus

Ac = Pi

for (Pi = n4rus) {
	while (Ac != q) {
		Pi += n4rus;
		}
	}
}

# Any joke is exactly what it seems to be.
# For each doubt, a doubt exists.
# Compare it and distort everything.
# Compare it to distort everything.
# n4rus is a character that evolves.
# A character is a variable.
# Any number or char is a var.
# For each set of vars, another set of vars.
# The total sum is less than the total.
