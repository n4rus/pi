#include <iostream>
using namespace std;
#include<cmath>
//24/08
//main function of pi
main () {
float user_numbers;
float f1, f2;

cout << "Type numbers, then enter:";
cin >> f1 >> f2;
cout << endl;

user_numbers = ((f1) + (f2));

cout << "Pi is equal to " << user_numbers;
cout << endl;
/*16:00 > 17:50*/

char user_data;
char d1(0:10);

cout << "Type data, then enter:";
cin >> d1;
cout << endl;

user_data = d1;

cout << "Pi is equal to " << user_data << endl;
cout << endl;
//25/08 21:33
  /*
program ( functions ( pagina_estatica ) =+ functions ) = cout ( function/cout**n ));
pagina_estatica = pi
*/
//21:38 
 
}
