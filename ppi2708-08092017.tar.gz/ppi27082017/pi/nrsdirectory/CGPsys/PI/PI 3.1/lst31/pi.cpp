#include <iostream>
using namespace std;
#include<cmath>
//main function of pi
main () {
float user_data;
float f1, f2;
/*
char user_data;
char f1, f2;
*/
/*float user_functions;
  char user_functions;
  char pi, pi_sys, content, links;
  char user_functions, database, content_total;
  char f1, f2;
  user_functions = ((f1 = functions) + (functions + f1))
*//*
  user_data = ((f1)+(f2))
*/
/*  database = [(user_functions + cin)];
  pi = pi_sys(input[((cin + database)/(user_functions))] = database);
  links = (input[((cin) + (database))]);
  content = (input[((cin) + (database))]);
  content_total = [((content) + (pi + links))];
*/
cout << "Type data, then enter:";
cin >> f1 >> f2;
cout << endl;

/*if(((f1) / (f1)) == (f1)) and (((f2) / (f2)) == (f2))
user_data = ((f1) + (f2));
else*/
user_data = ((f1) + (f2));
  
//cout <<  "Pi is equal to " << user_functions;

cout << "Pi is equal to " << user_data;
cout << endl;
/*
cout << "Enter next funtion:";
cin >> f2;

content = f2;

cout << "Pi content is equal to " << content;
cout << endl;
*/
/*16:00 > 17:50*/
}
