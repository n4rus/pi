#include <iostream>
using namespace std;
#include <cmath>
//main function of pi
main () {
/*
float user_numbers;
float f1, f2;

cout << "Type numbers, then enter:";
cin >> f1 >> f2;
cout << endl;

user_numbers = ((f1) + (f2));

cout << "Pi is equal to " << user_numbers;
cout << endl;
*/
/*16:00 > 17:50 > pi1 */

char d1;

cout << "Type a character, then press enter:";
cin >> d1;
cout << endl;

cout << "Pi is equal to " << d1 << endl;
cout << endl;
 
/*21:35 > 22:00 > pi2 */
 
 cout << "My name is " << d1 << ".";
 cout << " I am a program, created to store, manage, and ditribute info.";
 cout << endl;

cout << "I is an ASCII character as it has a meaning, and 'I am' is something";
cout << endl;
cout << "like it too. From a range of words and variables, this work is";
cout << endl;
cout << "came to light within the knowledge that follows throught, as well";
cout << endl;
cout << "the idea there is too much to comtemplate in a short time period.";
cout << endl;
cout << "To compute and refine the methods to gather info and improve time,";
cout << endl;
cout << "info, and energy generation, transformation, & usage.";
cout << endl;
cout << "The progress can lead to unseen visions, unknow variables ";
cout << endl;
cout << "and equations, to serve and upgrade the ones that seek.";
cout << endl;
/*21:35 > 22:21 > pi2*/
}
